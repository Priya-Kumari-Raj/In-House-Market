package com.cg.marketplace.dto;

public class CreateEmployeeRequest {

}
